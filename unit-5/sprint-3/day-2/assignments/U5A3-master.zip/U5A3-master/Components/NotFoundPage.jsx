export const NotFoundPage = () => {
  return (
    <div className="notfound">
      <img src="Show 404 not found image or gif" alt="" />
    </div>
  );
};
