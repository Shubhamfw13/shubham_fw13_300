import { Navbar } from "./Navbar";

export const Routes = () => {
  return (
    <>
      <Navbar />
      {/* Add Routes here */}
    </>
  );
};
