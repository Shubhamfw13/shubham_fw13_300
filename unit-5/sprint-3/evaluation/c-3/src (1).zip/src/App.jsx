import { AllRoutes } from "./Routes/Routes";

function App() {
  return (
    <div className="App">
      <AllRoutes />
    </div>
  );
}

export default App;
